<template>
    <div class="page-font">

        <Panel>{{message}}</Panel>

    </div>
</template>

<script>
    export default {
        data () {
            return {
                message: '字体',
            }
        },
        methods: {

        },
    }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>

</style>
