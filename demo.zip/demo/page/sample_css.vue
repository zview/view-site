<template>
    <div class="page-css">

        {{message}}

        <hr/>

        <input placeholder="请输入" disabled/>

        <Input type="text" bg-color="primary"/>

        <hr/>

    </div>
</template>

<script>
    export default {
        data () {
            return {
                message: '样式表',
            }
        },
        methods: {

        },
    }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>

</style>
